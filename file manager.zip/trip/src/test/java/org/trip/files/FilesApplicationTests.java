package org.trip.files;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
